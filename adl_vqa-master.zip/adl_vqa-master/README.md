# Visual Question Answering
Submission for Applied Deep Learning VQA

Some sample answers and true answers are shown below:

![Sample Answers on a validation dataset](https://github.com/saurabh1295/adl_vqa/blob/master/images/screen.png)

![Sample Answers on a validation dataset](https://github.com/saurabh1295/adl_vqa/blob/master/images/screen2.png)

We will add an image demo soon!

Ref. paper: https://arxiv.org/abs/1606.00061


Implemented by: Ritvik Shrivastava, Saurabh Sharma, Shivali Goel
